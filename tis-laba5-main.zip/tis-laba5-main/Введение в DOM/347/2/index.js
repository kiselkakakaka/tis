button.addEventListener('click', function(){
   let elem = document.querySelector('#elem');
   elem.innerHTML = '<b>text</b>';
   console.log(elem.innerHTML);
})