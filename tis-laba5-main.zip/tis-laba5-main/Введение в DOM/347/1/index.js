button.addEventListener('click', function(){
   let elem = document.querySelector('#elem');
   alert(elem.innerHTML);
})