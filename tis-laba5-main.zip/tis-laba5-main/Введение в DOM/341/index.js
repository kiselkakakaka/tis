   // Код, который нужно выполнить при клике на кнопку
    let elem1 = document.querySelector('#button1');
    let elem2 = document.querySelector('#button2');
    let elem3 = document.querySelector('#button3');

    button1.addEventListener('click', function() {
    alert(1);
    });

    button2.addEventListener('click', function() {
    alert(2);
    });

    button3.addEventListener('click', function() {
    alert(3);
});

