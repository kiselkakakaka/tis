function myFunction() {
    // Код, который нужно выполнить при клике на кнопку
    let elem1 = document.querySelector('#elem1');
    let elem2 = document.querySelector('#elem2');
    let elem3 = document.querySelector('#elem3');

    alert(elem1.innerText);
    alert(elem2.innerText);
    alert(elem3.innerText);
}

