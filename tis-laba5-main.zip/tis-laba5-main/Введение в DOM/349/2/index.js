let elem = document.querySelector('#elem');
let btn = document.querySelector('#button');
let para = document.querySelector('.abzac p')

button.addEventListener('click', function(){
    para.textContent = elem.value;
}
)