let elem = document.querySelector('#elem');
let btn = document.querySelector('#button')
button.addEventListener('click', function(){
    elem.value = 'new text';
    alert(elem.value);
}
)