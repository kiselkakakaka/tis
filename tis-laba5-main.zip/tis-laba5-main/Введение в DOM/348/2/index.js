let elem = document.querySelector('#elem');
elem.type = 'submit'
console.log(elem.type);