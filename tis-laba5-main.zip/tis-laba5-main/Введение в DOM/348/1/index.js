let elem = document.querySelector('#elem');
console.log(elem.type);