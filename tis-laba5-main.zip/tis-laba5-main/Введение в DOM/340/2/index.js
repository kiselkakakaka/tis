function myFunction() {
    let elem = document.querySelector('.block p');
    alert(elem);
}
