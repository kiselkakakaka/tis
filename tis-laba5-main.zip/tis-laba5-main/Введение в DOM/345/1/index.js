button.addEventListener('dblclick', function(){
   let button = document.querySelector('#button');
   alert('Как же сложно переключаться с Python на JS и наоборот')
})