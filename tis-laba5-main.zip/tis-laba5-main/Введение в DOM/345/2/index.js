button.addEventListener('mouseover', function(){
   let button = document.querySelector('#button');
   alert('Как же сложно переключаться с Python на JS и наоборот')
})