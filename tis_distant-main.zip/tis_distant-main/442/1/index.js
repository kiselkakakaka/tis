
  function outputSomething() {
    console.log('Something');
  }
  
  setInterval(outputSomething, 3000);