let arr = ['John', 'Smit', 'development', 'programmer', 2000];

let [ , , department, position] = arr;

console.log(department); 
console.log(position);
