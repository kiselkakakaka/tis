let options = {
    color: 'red',
    width:  400,
    height: 500,
   };
   
   let { color, width, height } = options;
   
   console.log(color);  
   console.log(width);  
   console.log(height); 
   