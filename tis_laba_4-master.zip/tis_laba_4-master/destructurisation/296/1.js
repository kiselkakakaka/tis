let arr = ['John', 'Smit', 'development', 'programmer', 2000];

let [name, surname, department, position, salary] = arr;

console.log(name);       
console.log(surname);   
console.log(department); 
console.log(position);   
console.log(salary);     
