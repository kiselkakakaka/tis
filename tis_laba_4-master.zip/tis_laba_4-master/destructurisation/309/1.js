function func(employee) {
  let [name, surname, department, position, salary] = employee;
}

func(['John', 'Smit', 'development', 'programmer', 2000]);
