function func(employee) {
  let [name, surname, department] = employee;
}

func(['John', 'Smit', 'development', 'programmer', 2000]);
