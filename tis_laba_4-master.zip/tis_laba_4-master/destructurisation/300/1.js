let arr = ['John', 'Smit', 'development', 'programmer', 2000];

let [name, surname, ...info] = arr;

console.log(name); 
console.log(surname);
console.log(info); 