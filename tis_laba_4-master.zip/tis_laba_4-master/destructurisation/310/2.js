function func(options) {
  let { width, height, color = 'black' } = options;
}

func({ color: 'red', width: 400, height: 500 });
