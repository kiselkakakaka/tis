function func(options) {
  let { color, width, height } = options;
}

func({ color: 'red', width: 400, height: 500 });
