let options = {
    width: 400,
    height: 500,
  };
  
  let { с: color = 'black', width: w, height: h } = options;
  