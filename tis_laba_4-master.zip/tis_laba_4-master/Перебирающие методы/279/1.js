let strings = ["Hello", "World", "JavaScript"];
let newStrings = strings.map((string) => string + "!");

console.log(newStrings);
