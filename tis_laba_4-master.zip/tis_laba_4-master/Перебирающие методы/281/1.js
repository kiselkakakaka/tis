let numbers = [1, -2, 3, -4, 5];
let positiveNumbers = numbers.filter((number) => number > 0);

console.log(positiveNumbers);
