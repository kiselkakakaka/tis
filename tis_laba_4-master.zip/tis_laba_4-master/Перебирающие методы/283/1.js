const numbers = [1, -3, 5, -2, 0];

const hasPositiveNumber = numbers.some(number => number > 0);

console.log(hasPositiveNumber);
