let numbers = [1, 2, 3, 4, 5];
let allPositive = numbers.every((number) => number > 0);

console.log(allPositive);
