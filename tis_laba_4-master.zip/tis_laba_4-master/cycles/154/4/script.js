
let arr = [1,4,3,2,0,5,23,213]
for(let elem of arr){
    console.log(elem);
    if(elem === 0){
        break;
    }
}