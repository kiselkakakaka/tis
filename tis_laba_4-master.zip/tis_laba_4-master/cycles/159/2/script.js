let arr = [];
for(let i = 1; i <= 10; i++){
    arr.push('x');
}