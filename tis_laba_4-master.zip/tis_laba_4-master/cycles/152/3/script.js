let str = '';

for(let i = 9; i > 0; i--){
    str += i;
}
console.log(str);