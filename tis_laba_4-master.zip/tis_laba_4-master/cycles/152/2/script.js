let str = '';
for(let i = 1; i < 10; i++){
    str += i;
    
}
console.log(str);