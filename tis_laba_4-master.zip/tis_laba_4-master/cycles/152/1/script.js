let str = '';
for(let i = 0; i < 5; i++){
    str += '-';
}