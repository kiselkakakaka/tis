let arr = [1,2,34,5,6,7,8]

for(let i = 0; i < arr.length; i++){
    console.log(arr[i]);
}