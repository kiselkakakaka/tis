let arr = ['a', 'b', 'c', 'd', 'e'];

for(let i = 1; i < arr.length - 1; i++){
    console.log(arr[i]);
}