for(let i = 100; i >= 0; i--){
    console.log(i);
}