for(let i = 11; i <= 33; i++){
    console.log(i);
}