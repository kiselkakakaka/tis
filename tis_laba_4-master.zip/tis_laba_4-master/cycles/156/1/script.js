for(let i = 1; i <= 9; i++){
    for(let j = 1; j <= 3; j++){
        console.log(i);
    }
}