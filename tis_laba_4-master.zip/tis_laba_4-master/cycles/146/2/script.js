let i = 11;
while(i <= 33){
    console.log(i);
    i++;
}