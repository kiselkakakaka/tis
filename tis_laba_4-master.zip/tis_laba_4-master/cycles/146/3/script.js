let i = 1;
let count = 0;
while(i <= 1000){
    count++;
    i *= 3;
    console.log(i)
}

console.log("Кол-во операций - " + count);