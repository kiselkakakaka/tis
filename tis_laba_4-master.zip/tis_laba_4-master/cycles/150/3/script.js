let res = 0;
for(let i = 1; i <= 20; i++){
    res *= i;
}