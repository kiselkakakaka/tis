for(let i = 10; i <= 1000; i++){
    let str = String(i);
    if(str[0] === '1'){
        console.log(str[0]);
    }
}