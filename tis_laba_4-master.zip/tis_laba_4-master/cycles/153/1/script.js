for(let i = 10; i <= 1000; i++){
    let str = String(i);
    console.log(str[0]);
}