for(let i = 10; i <= 1000; i++){
    let str = String(i);
    console.log(Number(str[0]) + Number(str[1]));
}