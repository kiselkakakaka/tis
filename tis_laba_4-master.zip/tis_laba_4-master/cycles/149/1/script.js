let arr = [2, 5, 9, 15, 1, 4];
for(let elem of arr){
    if(elem > 3 && elem < 10){
        console.log(elem);
    }
}