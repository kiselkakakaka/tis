let obj = {[key1]: 1, [key2]: 2, [key3]: 3};
let key1 = 'x';
let key2 = 'y';
let key3 = 'z';