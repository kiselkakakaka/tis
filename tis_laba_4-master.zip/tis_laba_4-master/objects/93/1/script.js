let key = 'x';

let obj = {
	[key]: 1,
	y: 2,
	z: 3
};