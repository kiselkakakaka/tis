let obj = {x: 1, y: 2, z: 3};
let key = 'x';
console.log(obj[key]);