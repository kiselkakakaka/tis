let obj = {x: 1, y: 2, z: 3};

console.log('x' in obj);
console.log('w' in obj);
