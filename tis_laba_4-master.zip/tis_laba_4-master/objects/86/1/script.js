let obj = {};

obj.a = 1;
obj.b = 2;
obj.c = 3;