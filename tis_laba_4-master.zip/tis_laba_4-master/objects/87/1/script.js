let obj = {3: 'c', 1: 'a', 2: 'b'};

console.log(obj[1]); 
console.log(obj[2]);
console.log(obj[3]); 