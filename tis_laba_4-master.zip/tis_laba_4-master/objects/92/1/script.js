let obj = {x: 1, y: 2, z: 3};
let prop = 'x';
console.log(obj[prop]);