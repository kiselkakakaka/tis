let user = {
    name: "Виталий",
    surname: "Витальев",
    patronymic: "Витальевич"
};

console.log(obj[name]);
console.log(obj[surname]);
console.log(obj[patronymic]);
