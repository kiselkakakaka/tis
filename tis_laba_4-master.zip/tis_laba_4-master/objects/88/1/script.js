let obj = {x:1, y:2, z:3};
let keys = Object.keys(obj);

console.log(keys);
console.log(obj);