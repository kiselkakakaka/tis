let arr = [1, 2, 3, 4, 5];
console.log(arr.length - 1);