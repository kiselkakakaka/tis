let arr = [1,2,3];

arr[0] += 3;
arr[1] += 3;
arr[2] += 3;
console.log(arr);