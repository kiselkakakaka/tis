let arr = ['a', 'b', 'c'];
console.log(arr.length - 1)