let arr = [];

arr[3] = 'a';
arr[8] = 'b';
console.log(arr.length);