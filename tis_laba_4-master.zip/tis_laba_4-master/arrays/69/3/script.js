let array = [1,2,3];
console.log(array[0] + array[1] + array[2]);
