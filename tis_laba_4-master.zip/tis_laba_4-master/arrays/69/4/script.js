let arr = ['a', 'b', 'c', 'd'];

console.log(`${arr[0]} + ${arr[1]} + ${arr[2]} + ${arr[3]}`);