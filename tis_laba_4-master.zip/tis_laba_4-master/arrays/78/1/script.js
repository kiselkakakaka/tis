let arr = [1,2,3,4,5,6];
delete arr[1];
delete arr[2];
console.log(arr.length);