let arr = [];

arr[0] = 'a';
arr[1] = 'b';
arr[2] = 'c';