let arr = [1,2,3];

arr[3] = 4;
arr[4] = 5;