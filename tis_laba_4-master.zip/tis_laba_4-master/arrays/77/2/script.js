let arr = [1,2,3];

let key1 = 1; let key2 = 2;
console.log(arr[key1] + arr[key2]);