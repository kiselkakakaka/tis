let arr = ['a', 'b', 'c'];

let key = 2;

console.log(arr[key]);