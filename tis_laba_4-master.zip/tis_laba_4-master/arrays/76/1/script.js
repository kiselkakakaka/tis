let arr = [];

arr.push(1);
arr.push(2);
arr.push(3);