let arr = [1,2,3];

arr.push(4);
arr.push(5);