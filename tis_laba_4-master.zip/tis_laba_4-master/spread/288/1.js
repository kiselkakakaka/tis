let numbers = [4, 2, 7, 1, 9, 5];

let minValue = Math.min(...numbers);

console.log(minValue);

