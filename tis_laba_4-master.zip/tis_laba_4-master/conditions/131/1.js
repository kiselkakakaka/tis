let num = 1;
let res = num >= 0 ? 1: 2;

console.log(res);