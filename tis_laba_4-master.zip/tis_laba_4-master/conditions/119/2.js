let test = 1;
		
if (test == true) {
	console.log('+++'); //вывод
} else {
	console.log('---');
}