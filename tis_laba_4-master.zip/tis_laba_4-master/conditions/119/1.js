let test = 0;
let test1 = !1;
if (Boolean(test) == false || Boolean(test1) == false) {
	console.log('+++');
} else {
	console.log('---');
}