let str = 'sashx';
let last = str[str.length - 1];

if (last == 'x') {
	console.log('Первый символ в строке: x');
}
if (last !== 'x') {
	console.log('Первый символ в строке не x');
}