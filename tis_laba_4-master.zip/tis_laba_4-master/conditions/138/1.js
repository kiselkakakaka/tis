let str = 'sasha';
let first = str[str.length - 5];

if (first == 'a') {
	console.log('Первый символ в строке: а');
}
if (first !== 'a') {
	console.log('Первый символ в строке не а');
}