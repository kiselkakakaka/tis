let test = true;

if (test) {
	console.log('+++');
} else {
	console.log('---');
}