let test = 3;

if (test) {
	console.log('+++'); //вывод
} else {
	console.log('---');
}