let test = 'abc';

if (test) {
	console.log('+++'); //вывод
} else {
	console.log('---');
}