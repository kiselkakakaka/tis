let num1 = 0;
let num2 = 0;

if (num1 >= 0 || num2 >= 0) {
	console.log('+++'); //вывод
} else {
	console.log('---');
}