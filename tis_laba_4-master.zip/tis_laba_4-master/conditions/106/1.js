let num = 10;

if (num == 10){
    console.log('num = ' + num)
}
if(num < 10){
    console.log('num = ' + num)
    console.log('num < 10')
}
if(num > 10) {
    console.log('num = ' + num)
    console.log('num > 10')
}