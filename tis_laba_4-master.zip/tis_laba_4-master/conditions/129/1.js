let lang = 'pol';

switch (lang) {
	case 'ru':
		console.log('русский');
	break;
	case 'en':
		console.log('английский');
	break;
	case 'de':
		console.log('немецкий');
	break;
	default:
		console.log('язык не поддерживается');
	break;
}