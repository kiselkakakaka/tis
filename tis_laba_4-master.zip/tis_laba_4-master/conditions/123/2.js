let test1 = true;
let test2 = true;

if (test1 && !test2) { 
	console.log('+++');
} else {
	console.log('---');
}