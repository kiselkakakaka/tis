let test = 1;

if (test == 10) {
	console.log('yes');
}