let test1 = 10;
let test2 = 5;

if (test1 > test2) {
  console.log("Значение переменной test1 больше значения переменной test2");
} else if (test2 > test1) {
  console.log("Значение переменной test2 больше значения переменной test1");
} else {
  console.log("Значения переменных test1 и test2 равны");
}
