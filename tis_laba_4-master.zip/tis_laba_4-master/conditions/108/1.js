let test1 = 5;
let test2 = 10;

if (test1 > test2) {
  console.log("Значение переменной test1 больше значения переменной test2");
} else {
  console.log("Значение переменной test2 больше значения переменной test1");
} 
