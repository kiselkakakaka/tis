let num = 3;

if (num > 0 && num < 5) {
	console.log('+++');
} else {
	console.log('---');
}