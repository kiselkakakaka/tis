let num = 11;

if (num >= 10 && num <= 20) {
	console.log('+++');
} else {
	console.log('---');
}