let min = 10;

if (min >= 0 && min <= 20) {
	console.log('1 треть часа');
}

if (min >= 21 && min <= 40) {
	console.log('2 треть часа');
}

if (min >= 41 && min <= 60) {
	console.log('3 треть часа');
}
