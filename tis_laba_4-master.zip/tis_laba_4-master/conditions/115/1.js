if (num == 0 || num > 1 && num 
	< 5 ) { 
	console.log('+++');
} else {
	console.log('---');
}
//Сначала логическое И (num > 1 && num 
//	< 5), потом логическое ИЛИ (num == 0 ||)