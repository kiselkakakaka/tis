let str = 'abcde';

if (str.charAt(0) === 'a') {
    console.log('да');
} else {
    console.log('нет');
}
