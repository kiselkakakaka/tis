let num = 11;

if (num < 10){
    console.log('num = ' + num)
    console.log('num < 10')
}
else {
    console.log('num = ' + num)
    console.log('num > 10')
}