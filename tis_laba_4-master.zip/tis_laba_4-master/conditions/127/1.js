let day = 22;

if (day >= 1  && day <= 10) {
    console.log('1 декада');
} else if (day >= 11  && day <= 20) {
    console.log('2 декада');
} else if (day >= 21  && day <= 31) {
    console.log('3 декада');
}