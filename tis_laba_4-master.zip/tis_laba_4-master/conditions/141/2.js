let num1 = 1; //убрал одинарные ковычки
let num2 = 2; //убрал одинарные ковычки

if (num1 + num2 === 3) {
	console.log('+++');
} else {
	console.log('---');
}