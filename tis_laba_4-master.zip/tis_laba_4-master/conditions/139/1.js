let num = 12340;
let last = String(num)[4];

if (last == 0) {
	console.log('Последнее число в строке равно 0');
} else {
	console.log('Последнее число в строке не равно 0');
}