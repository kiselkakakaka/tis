let arr = [2,4,5];
if (arr.length = 3){
	let sum = arr[0] + arr[1] + arr[2];
	console.log("Сумма элементов массива из трех чисел равна: " + sum)
}
else{
	console.log("Сумма неизвестна, потому что в массиве больше 3 чисел")
}