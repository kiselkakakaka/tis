let a = 11;
let b = 3;
let rest = a % b;

if (rest === 0) {
	console.log('Делится нацело на 3');
} else {
	console.log('Делится с остатком ' + rest); 
}