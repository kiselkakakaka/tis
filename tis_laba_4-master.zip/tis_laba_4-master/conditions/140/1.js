let a = 11;
let b = 2;
let rest = a % b;

if (rest === 0) {
	console.log('делится нацело');
} else {
	console.log('делится с остатком ' + rest); 
}