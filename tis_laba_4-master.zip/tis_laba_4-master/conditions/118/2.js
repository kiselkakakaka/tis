let test = true;

if (test === false) {
	console.log('+++');
} else {
	console.log('---');
}