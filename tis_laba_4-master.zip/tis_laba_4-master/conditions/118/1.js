let test = true;

if (test === true) {
	console.log('+++');
} else {
	console.log('---');
}