let test1 = '123';
let test2 = 123;

if (test1 === test2) {
  console.log("Значения переменных test1 и test2 равны");
} else {
  console.log("Значения переменных test1 и test2 не равны");
}
