let a = 2 * (3 - 1);
let b = 6 - 2;

let res = a == b;
console.log(res);