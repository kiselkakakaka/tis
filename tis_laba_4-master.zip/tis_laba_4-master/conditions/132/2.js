let a = 5 * (7 - 4);
let b = 1 + 2 + 7;

let res = a > b;
console.log(res);