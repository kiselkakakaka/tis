func();

function func() {
	console.log('Александр');
}