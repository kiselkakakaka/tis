function sqrt(num) {
  return Math.sqrt(num);
}

function sum(num1, num2, num3) {
  return num1 + num2 + num3;
}

let res = sum(sqrt(2), sqrt(3), sqrt(4));
console.log(res);