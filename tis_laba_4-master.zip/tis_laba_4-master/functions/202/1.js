func(1,2,3);

function func(num1, num2, num3) {
	console.log(num1 + num2 + num3);
}