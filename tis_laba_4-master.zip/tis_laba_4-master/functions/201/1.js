cube(3);

function cube(num) {
	let res = num**3;
	console.log(res)
}