num(3);

function num(number) {
	if (number > 0)
	{console.log('+++')}
	else if (number > 0)
	{console.log('---')}
	else
	{console.log('0')}
}