function sqrt(num) {
	return Math.sqrt(num);
  }
  
  let res = sqrt(3) + sqrt(4);
  console.log(res);
  
