function cube(num) {
	return num ** 3;
  }
  
  let res = cube(3);
  console.log(res);
  