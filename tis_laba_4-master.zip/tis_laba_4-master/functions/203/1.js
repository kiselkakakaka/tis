let param1 = 1;
let param2 = 2;
let param3 = 3;
function func(sum){
	console.log(param1+param2+param3)
}
func()
