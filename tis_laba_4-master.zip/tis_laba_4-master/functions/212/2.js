function func(a, b) {
	return a != b
}
console.log(func(1,1))