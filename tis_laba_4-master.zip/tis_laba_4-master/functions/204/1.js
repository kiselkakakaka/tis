function func(num = 5) {
	console.log(num * num);
  }
  func(2);
  func(3);
  func();
  
