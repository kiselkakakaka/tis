function func1() {
	return 3;
  }
  
  function func2() {
	return 5;
  }
  
  console.log(func1() + func2()); 
  